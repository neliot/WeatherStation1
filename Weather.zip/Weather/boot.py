############################################
# TITLE  # GENERIC SPLASH SCREEN LAUNCHER
# AUTHOR # DR NEIL ELIOT
# DATE   # 08/01/2023
############################################
# NOTES
###################################################################################
# BEWARE ONLY USE THE INTERNAL DHT11 LIBRARY WHEN USING THIS LAUNCHER OR IT FREEZES
###################################################################################
from machine import Pin
from ssd1306 import SSD1306_I2C
import framebuf
import time

i2c = machine.I2C(0,sda=Pin(16), scl=Pin(17), freq=400000)
oled = SSD1306_I2C(128, 64, i2c)

prevTemp = 0
prevHumi = 0

def splash(file):
    with open(file, 'rb') as f:
        f.readline() # Magic number
        f.readline() # Creator comment
        f.readline() # Dimensions
        data = bytearray(f.read())
    fbuf = framebuf.FrameBuffer(data, 128, 64, framebuf.MONO_HLSB)
    oled.blit(fbuf, 0, 0)
    oled.show()

splash('su.pbm')                                               # SPLASH SCREENS
time.sleep(2)                                                  
splash('fot.pbm')
time.sleep(2)
splash('socs.pbm')
time.sleep(2)

